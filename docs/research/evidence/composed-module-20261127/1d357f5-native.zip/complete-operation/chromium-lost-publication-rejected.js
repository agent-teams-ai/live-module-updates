import { copyAuthoritySnapshot, copyLookup, copyPublicationResult, copyUpdateRequest, updateBinding, } from "./models.js";
import { captureCleanupReport } from "./cleanup-report.js";
import { authorityInFlight, originalCleanupObserved, snapshot, terminal } from "./operation-state.js";
function isClosed(coordinator) {
    return coordinator.closed;
}
function owners(coordinator) {
    const { attempts, initialOwner } = coordinator;
    return [initialOwner, ...attempts.values()];
}
function ownerFor(coordinator, generationId) {
    const { attempts, initialOwner } = coordinator;
    if (initialOwner.generationId === generationId) {
        return initialOwner;
    }
    for (const attempt of attempts.values()) {
        if (attempt.generationId === generationId && attempt.control) {
            return attempt;
        }
    }
    return undefined;
}
function candidateCount(coordinator) {
    const { attempts } = coordinator;
    let count = 0;
    for (const attempt of attempts.values()) {
        if (attempt.candidateSlot) {
            count += 1;
        }
    }
    return count;
}
function retirementBudget(coordinator) {
    const { attempts } = coordinator;
    const ids = new Set();
    for (const owner of owners(coordinator)) {
        if (owner.retiringPredecessor && owner.control?.snapshot().retained === true) {
            ids.add(owner.generationId);
        }
    }
    for (const attempt of attempts.values()) {
        if (attempt.reservedPredecessor !== undefined) {
            ids.add(attempt.reservedPredecessor);
        }
    }
    return ids;
}
function ownershipReleased(coordinator) {
    return coordinator.closed && coordinator.invocation.pending() === 0
        && owners(coordinator).every(owner => !owner.pendingPreparation && !owner.pendingPublication
            && owner.custody === undefined && owner.control?.snapshot().retained !== true)
        && [...coordinator.attempts.values()].every(attempt => !authorityInFlight(attempt));
}
function inspect(coordinator) {
    const { domainId, invocation, attempts } = coordinator;
    const retained = owners(coordinator).filter(owner => owner.retiringPredecessor && owner.control?.snapshot().retained === true);
    const reserved = new Set();
    for (const attempt of attempts.values()) {
        if (attempt.reservedPredecessor !== undefined) {
            reserved.add(attempt.reservedPredecessor);
        }
    }
    return Object.freeze({
        domainId, closed: coordinator.closed, ownershipReleased: ownershipReleased(coordinator),
        attempts: Object.freeze([...attempts.values()].map(snapshot)),
        generations: Object.freeze(invocation.generations().map(control => control.snapshot())),
        candidates: candidateCount(coordinator),
        retainedPredecessors: retained.length,
        reservedPredecessors: Object.freeze([...reserved]),
    });
}
function refresh(coordinator) {
    const { attempts } = coordinator;
    // Several native closes may settle in the same turn. Reclaim every eligible
    // exact owner before publishing a terminal snapshot, regardless of callback order.
    for (const owner of owners(coordinator)) {
        forget(coordinator, owner);
    }
    for (const attempt of attempts.values()) {
        if (!attempt.settled && terminal(attempt)) {
            attempt.settled = true;
            attempt.completion.resolve(snapshot(attempt));
        }
    }
    if (!coordinator.closeFlight) {
        return;
    }
    if ([...attempts.values()].some(authorityInFlight)) {
        return;
    }
    if (owners(coordinator).some(owner => owner.pendingPreparation || owner.pendingPublication || !originalCleanupObserved(owner))) {
        return;
    }
    if ([...attempts.values()].some(attempt => attempt.unregisteredCleanup?.original.status === "pending")) {
        return;
    }
    const current = inspect(coordinator);
    coordinator.closeFlight.resolve(Object.freeze({ complete: current.ownershipReleased, snapshot: current }));
}
function forget(coordinator, owner) {
    const { attempts } = coordinator;
    if (owner.pendingPreparation || owner.pendingPublication || !owner.retirementRequested || !owner.control) {
        return;
    }
    if (owner.control.forget().status === "forgotten") {
        owner.custody = undefined;
        for (const attempt of attempts.values()) {
            if (attempt === owner) {
                attempt.candidateSlot = false;
            }
        }
    }
}
function retire(coordinator, owner) {
    owner.retirementRequested = true;
    owner.control?.seal();
    if (owner.pendingPreparation || owner.pendingPublication || !owner.control || owner.retirementFlight) {
        return;
    }
    const done = Promise.withResolvers();
    owner.retirementFlight = done.promise;
    let closing;
    try {
        closing = owner.control.close();
    }
    catch (cause) {
        closing = Promise.reject(cause);
    }
    void closing.then(() => {
        forget(coordinator, owner);
        done.resolve();
        refresh(coordinator);
        return null;
    }, () => {
        // The exact control retains the original failed cleanup evidence.
        done.resolve();
        refresh(coordinator);
    });
}
async function observeAdoption(coordinator, attempt) {
    const { invocation, adoptionProbe } = coordinator;
    if (!adoptionProbe || coordinator.closed) {
        attempt.adoption = Object.freeze({ status: "not-requested" });
        refresh(coordinator);
        return;
    }
    attempt.adoption = Object.freeze({ status: "pending" });
    try {
        const outcome = await invocation.invokeExpected(attempt.generationId, ...adoptionProbe.args);
        if (outcome.status === "refused" && (outcome.reason === "generation-changed" || outcome.reason === "generation-unavailable")) {
            attempt.adoption = Object.freeze({ status: "superseded" });
        }
        else if (outcome.status === "returned" && outcome.generationId === attempt.generationId && adoptionProbe.accept(outcome.value)) {
            attempt.adoption = Object.freeze({ status: "observed", generationId: outcome.generationId });
        }
        else {
            attempt.adoption = Object.freeze({ status: "failed", cause: outcome });
        }
    }
    catch (cause) {
        attempt.adoption = Object.freeze({ status: "failed", cause });
    }
    refresh(coordinator);
}
function acceptReceipt(coordinator, attempt, result) {
    if (attempt.publication.status !== "unknown") {
        const original = attempt.publication;
        const matching = (original.status === "committed" || original.status === "rejected")
            && (result.status === "committed" || result.status === "rejected")
            && JSON.stringify(original.receipt) === JSON.stringify(result);
        if (!matching && !(original.status === "refused" && result.status === "refused" && original.reason === result.reason)) {
            attempt.observationIssue = new Error("The authority contradicted its original terminal outcome");
        }
        return;
    }
    attempt.pendingPublication = false;
    attempt.reservedPredecessor = undefined;
    if (result.status === "committed") {
        attempt.publication = Object.freeze({ status: "committed", receipt: result });
        attempt.candidateSlot = false;
        if (attempt.predecessor) {
            attempt.predecessor.retiringPredecessor = true;
            retire(coordinator, attempt.predecessor);
        }
        // Start useful observation before terminal completion can be reported.
        void observeAdoption(coordinator, attempt);
        if (attempt.retirementRequested) {
            retire(coordinator, attempt);
        }
    }
    else {
        attempt.publication = result.status === "rejected"
            ? Object.freeze({ status: "rejected", receipt: result })
            : Object.freeze({ status: "refused", reason: result.reason });
        attempt.adoption = Object.freeze({ status: "not-requested" });
        retire(coordinator, attempt);
    }
    refresh(coordinator);
}
function uncertain(coordinator, attempt, cause) {
    if (attempt.publication.status !== "unknown") {
        if (cause !== undefined) {
            attempt.observationIssue = cause;
        }
        return;
    }
    acceptReceipt(coordinator, attempt, { status: "refused", reason: "mutant classified unknown publication as rejection" });
    refresh(coordinator);
}
function finishPublicationResponse(coordinator, attempt) {
    attempt.publicationResponsePending = false;
    refresh(coordinator);
}
function requestPublication(coordinator, attempt, baseline) {
    const { domainId, publish } = coordinator;
    const request = Object.freeze({
        domainId, attemptId: attempt.request.attemptId, candidate: attempt.request.candidate,
        expectedHead: baseline.head, basis: baseline.basis,
    });
    attempt.publicationRequest = request;
    attempt.publicationResponsePending = true;
    attempt.pendingPublication = true;
    attempt.publication = Object.freeze({ status: "unknown" });
    try {
        const raw = publish(request);
        void Promise.resolve(raw).then(value => {
            try {
                const result = copyPublicationResult(value, request);
                if (!result) {
                    uncertain(coordinator, attempt, new Error("Malformed or unbound publication response"));
                }
                else if (result.status === "unknown") {
                    uncertain(coordinator, attempt);
                }
                else {
                    acceptReceipt(coordinator, attempt, result);
                }
                return null;
            }
            catch (cause) {
                uncertain(coordinator, attempt, cause);
                return null;
            }
            finally {
                finishPublicationResponse(coordinator, attempt);
            }
        }, (cause) => {
            try {
                uncertain(coordinator, attempt, cause);
            }
            finally {
                finishPublicationResponse(coordinator, attempt);
            }
            return null;
        });
    }
    catch (cause) {
        try {
            uncertain(coordinator, attempt, cause);
        }
        finally {
            finishPublicationResponse(coordinator, attempt);
        }
    }
}
async function observeUnregisteredNative(attempt, retry) {
    if (!attempt.custody) {
        throw new Error("No native custody is available");
    }
    let value;
    try {
        const native = attempt.custody.close();
        if (!retry) {
            attempt.unregisteredOriginal = native;
        }
        value = await native;
    }
    catch (cause) {
        return Object.freeze({ status: "failed", cause, retryable: true });
    }
    try {
        return Object.freeze({ status: "settled", report: captureCleanupReport(value) });
    }
    catch (cause) {
        return Object.freeze({ status: "failed", cause, retryable: false });
    }
}
async function closeUnregistered(coordinator, attempt, retry = false) {
    if (!attempt.custody || (!retry && attempt.unregisteredCleanup)) {
        return;
    }
    const previous = attempt.unregisteredCleanup;
    const pending = Object.freeze({ status: "pending" });
    const original = retry && previous ? previous.original : pending;
    const retryCount = (previous?.retryCount ?? 0) + (retry ? 1 : 0);
    attempt.unregisteredCleanup = Object.freeze({ requested: true, original, latest: pending, retryCount });
    const latest = await observeUnregisteredNative(attempt, retry);
    attempt.unregisteredCleanup = Object.freeze({ requested: true, original: retry ? original : latest, latest, retryCount });
    if (latest.status === "settled" && latest.report.complete) {
        attempt.custody = undefined;
        attempt.candidateSlot = false;
    }
    refresh(coordinator);
}
async function prepare(coordinator, attempt, baseline) {
    const { domainId, invocation, checkCompatibility, open } = coordinator;
    try {
        const compatible = checkCompatibility(Object.freeze({ candidate: attempt.request.candidate, current: baseline }));
        if (compatible.status !== "compatible") {
            attempt.planning = Object.freeze({ status: "refused", reason: compatible.reason });
            return;
        }
        if (attempt.predecessor?.control?.snapshot().installed !== true) {
            attempt.planning = Object.freeze({ status: "refused", reason: "unowned-current-generation" });
            return;
        }
        if (isClosed(coordinator)) {
            attempt.planning = Object.freeze({ status: "refused", reason: "runtime-closed" });
            return;
        }
        attempt.planning = Object.freeze({ status: "ready", baseline });
        const custody = open(Object.freeze({ domainId, request: attempt.request, baseline }));
        attempt.custody = custody;
        const release = custody.close.bind(custody);
        const reservation = invocation.reserveGeneration({ generationId: attempt.generationId, release });
        if (reservation.status !== "reserved") {
            throw new Error(`Cannot retain the preparation owner: ${reservation.reason}`);
        }
        attempt.control = reservation.control;
        if (isClosed(coordinator)) {
            throw new Error("Runtime closed before candidate preparation");
        }
        attempt.preparation = Object.freeze({ status: "pending" });
        const prepared = await custody.prepare();
        if (isClosed(coordinator)) {
            throw new Error("Runtime closed while candidate preparation was outstanding");
        }
        const invoke = prepared.invoke;
        if (typeof invoke !== "function") {
            throw new Error("Cannot install prepared generation: invalid-entry");
        }
        const installed = attempt.control.install(invoke.bind(prepared));
        if (installed.status !== "installed") {
            throw new Error(`Cannot install prepared generation: ${installed.reason}`);
        }
        attempt.preparation = Object.freeze({ status: "ready" });
        attempt.pendingPreparation = false;
        requestPublication(coordinator, attempt, baseline);
    }
    catch (cause) {
        if (attempt.planning.status === "pending") {
            attempt.planning = Object.freeze({ status: "failed", cause });
        }
        else {
            attempt.preparation = Object.freeze({ status: "failed", cause });
        }
    }
    finally {
        attempt.pendingPreparation = false;
        if (attempt.publication.status === "not-requested") {
            attempt.reservedPredecessor = undefined;
            attempt.adoption = Object.freeze({ status: "not-requested" });
            if (attempt.control) {
                retire(coordinator, attempt);
            }
            else if (attempt.custody) {
                void closeUnregistered(coordinator, attempt);
            }
            else {
                attempt.candidateSlot = false;
            }
        }
        else if (attempt.retirementRequested) {
            retire(coordinator, attempt);
        }
        refresh(coordinator);
    }
}
function reconcile(coordinator, attempt) {
    const { lookup } = coordinator;
    const request = attempt.publicationRequest;
    if (!request || attempt.publication.status !== "unknown") {
        return Promise.resolve(snapshot(attempt));
    }
    if (attempt.reconcileFlight) {
        return attempt.reconcileFlight;
    }
    const done = Promise.withResolvers();
    attempt.reconcileFlight = done.promise;
    void (async () => {
        try {
            const result = copyLookup(await lookup(request), request);
            if (!result) {
                uncertain(coordinator, attempt, new Error("Malformed or unbound original-attempt receipt"));
            }
            else if (result.status === "known") {
                acceptReceipt(coordinator, attempt, result.receipt);
            }
            else {
                uncertain(coordinator, attempt);
            }
        }
        catch (cause) {
            uncertain(coordinator, attempt, cause);
        }
        finally {
            attempt.reconcileFlight = undefined;
            refresh(coordinator);
            done.resolve(snapshot(attempt));
        }
    })();
    return done.promise;
}
function retryable(state) {
    return state?.status === "failed" ? state.retryable
        : state?.status === "settled" && state.report.settled && !state.report.complete;
}
async function retryOwner(coordinator, owner) {
    if (!owner?.control || !owner.retirementRequested || owner.pendingPreparation || owner.pendingPublication) {
        return;
    }
    const latest = owner.control.snapshot().cleanup.latest;
    if (!retryable(latest)) {
        return;
    }
    await owner.control.retryCleanup();
    forget(coordinator, owner);
    refresh(coordinator);
}
async function retryCleanup(coordinator, attempt) {
    const owner = attempt.publication.status === "committed" ? attempt.predecessor : attempt;
    try {
        await retryOwner(coordinator, owner);
        if (owner === attempt && !attempt.control && retryable(attempt.unregisteredCleanup?.latest)) {
            await closeUnregistered(coordinator, attempt, true);
        }
    }
    catch (cause) {
        attempt.observationIssue = cause;
    }
    return snapshot(attempt);
}
function retryRuntimeCleanup(coordinator) {
    if (coordinator.retryFlight) {
        return coordinator.retryFlight;
    }
    const done = Promise.withResolvers();
    coordinator.retryFlight = done.promise;
    void (async () => {
        const native = owners(coordinator).map(owner => retryOwner(coordinator, owner));
        for (const attempt of coordinator.attempts.values()) {
            if (!attempt.control && retryable(attempt.unregisteredCleanup?.latest)) {
                native.push(closeUnregistered(coordinator, attempt, true));
            }
        }
        // Each exact owner retains its own rejection/debt; other owners still progress.
        await Promise.allSettled(native);
        coordinator.retryFlight = undefined;
        refresh(coordinator);
        done.resolve(inspect(coordinator));
    })();
    return done.promise;
}
function startUpdate(coordinator, input) {
    const { domainId, limits, read, attempts, initialOwner } = coordinator;
    let request;
    try {
        request = copyUpdateRequest(input);
    }
    catch {
        request = undefined;
    }
    if (!request) {
        return Object.freeze({ status: "refused", reason: "invalid-request" });
    }
    const binding = updateBinding(request);
    const existing = attempts.get(request.attemptId);
    if (existing) {
        return existing.binding === binding
            ? Object.freeze({ status: "replayed", handle: existing.handle })
            : Object.freeze({ status: "refused", reason: "attempt-payload-mismatch" });
    }
    if (coordinator.closed) {
        return Object.freeze({ status: "refused", reason: "closed" });
    }
    if (attempts.size >= limits.maxAttempts) {
        return Object.freeze({ status: "refused", reason: "attempt-capacity" });
    }
    if (candidateCount(coordinator) >= limits.maxCandidates) {
        return Object.freeze({ status: "refused", reason: "candidate-capacity" });
    }
    if (request.candidate.generationId === initialOwner.generationId
        || [...attempts.values()].some(value => value.generationId === request.candidate.generationId)) {
        return Object.freeze({ status: "refused", reason: "generation-reused" });
    }
    let baseline;
    let readIssue;
    try {
        baseline = copyAuthoritySnapshot(read());
        if (!baseline || baseline.domainId !== domainId) {
            throw new Error("Invalid canonical authority snapshot");
        }
    }
    catch (cause) {
        readIssue = cause;
        baseline = undefined;
    }
    if (baseline) {
        const budget = retirementBudget(coordinator);
        budget.add(baseline.head.generationId);
        if (budget.size > limits.maxRetainedPredecessors) {
            return Object.freeze({ status: "refused", reason: "retention-capacity" });
        }
    }
    const completion = Promise.withResolvers();
    // The handle closes over the subsequently assigned record; no external callback
    // can reach it before the record is registered below.
    const handle = Object.freeze({
        attemptId: request.attemptId,
        completion: completion.promise,
        inspect: () => snapshot(attempt),
        reconcile: () => reconcile(coordinator, attempt),
        retryCleanup: () => retryCleanup(coordinator, attempt),
    });
    const attempt = {
        generationId: request.candidate.generationId, request, binding, completion, handle,
        baseline, predecessor: baseline ? ownerFor(coordinator, baseline.head.generationId) : undefined,
        control: undefined, custody: undefined, pendingPreparation: true, pendingPublication: false,
        retirementRequested: false, retiringPredecessor: false, retirementFlight: undefined,
        planning: Object.freeze({ status: "pending" }), preparation: Object.freeze({ status: "not-started" }),
        publication: Object.freeze({ status: "not-requested" }), adoption: Object.freeze({ status: "not-started" }),
        publicationRequest: undefined, publicationResponsePending: false, reconcileFlight: undefined, candidateSlot: true,
        reservedPredecessor: baseline?.head.generationId, unregisteredCleanup: undefined, unregisteredOriginal: undefined,
        settled: false, observationIssue: undefined,
    };
    attempts.set(request.attemptId, attempt);
    if (baseline) {
        void prepare(coordinator, attempt, baseline);
    }
    else {
        attempt.pendingPreparation = false;
        attempt.planning = Object.freeze({ status: "failed", cause: readIssue });
        attempt.adoption = Object.freeze({ status: "not-requested" });
        attempt.candidateSlot = false;
        refresh(coordinator);
    }
    return Object.freeze({ status: "started", handle });
}
function close(coordinator) {
    const { invocation } = coordinator;
    if (coordinator.closeFlight) {
        return coordinator.closeFlight.promise;
    }
    coordinator.closeFlight = Promise.withResolvers();
    coordinator.closed = true;
    invocation.seal();
    for (const owner of owners(coordinator)) {
        retire(coordinator, owner);
    }
    refresh(coordinator);
    return coordinator.closeFlight.promise;
}
export function createUpdateCoordinator(options) {
    const coordinator = {
        domainId: options.domainId,
        invocation: options.invocation,
        limits: options.limits,
        read: options.authority.read.bind(options.authority),
        publish: options.authority.publish.bind(options.authority),
        lookup: options.authority.lookup.bind(options.authority),
        checkCompatibility: options.compatibility.check.bind(options.compatibility),
        open: options.preparation.open.bind(options.preparation),
        adoptionProbe: options.adoption,
        attempts: new Map(),
        initialOwner: {
            generationId: options.initial.candidate.generationId,
            control: options.initial.control,
            custody: undefined,
            pendingPreparation: false,
            pendingPublication: false,
            retirementRequested: false,
            retiringPredecessor: false,
            retirementFlight: undefined,
        },
        closed: false,
        closeFlight: undefined,
        retryFlight: undefined,
    };
    return Object.freeze({
        startUpdate: (request) => startUpdate(coordinator, request),
        inspect: () => inspect(coordinator),
        close: () => close(coordinator),
        retryCleanup: () => retryRuntimeCleanup(coordinator),
    });
}
