import { createGenerationRecord } from "./generation.js";
function refused(reason) {
    return Promise.resolve({ status: "refused", reason });
}
/**
 * One cooperative execution agent and one Host-owned canonical head. No callback
 * or await separates the inert owner snapshot from the exact work reservation.
 */
export function createInvocationBoundary(options) {
    const { readCanonicalHead, maxActiveWork, maxGenerationIdentities } = options;
    if (typeof readCanonicalHead !== "function"
        || !Number.isSafeInteger(maxActiveWork) || maxActiveWork < 1
        || !Number.isSafeInteger(maxGenerationIdentities) || maxGenerationIdentities < 1) {
        throw new TypeError("invocation requires a canonical-head reader and explicit positive work/identity limits");
    }
    const entries = new Map();
    const usedIdentities = new Set();
    const sharedWork = new Set();
    let sealed = false;
    function reserveGeneration(spec) {
        const { generationId, release } = spec;
        if (typeof generationId !== "string" || generationId.length === 0) {
            return { status: "refused", reason: "invalid-generation" };
        }
        if (typeof release !== "function") {
            return { status: "refused", reason: "invalid-owner" };
        }
        if (usedIdentities.has(generationId)) {
            return { status: "refused", reason: "generation-reused" };
        }
        if (usedIdentities.size >= maxGenerationIdentities) {
            return { status: "refused", reason: "generation-capacity" };
        }
        const record = createGenerationRecord({
            generationId, release, sealed, sharedWork, maxActiveWork,
            forgetRegistration: (control) => { if (entries.get(generationId)?.control === control) {
                entries.delete(generationId);
            } },
        });
        usedIdentities.add(generationId);
        entries.set(generationId, record);
        return { status: "reserved", control: record.control };
    }
    function attachGeneration(spec) {
        const { generationId, invoke, release } = spec;
        if (typeof invoke !== "function") {
            return { status: "refused", reason: "invalid-owner" };
        }
        const reserved = reserveGeneration({ generationId, release });
        if (reserved.status === "reserved") {
            reserved.control.install(invoke);
        }
        return reserved;
    }
    function selectAndInvoke(expected, args) {
        if (sealed) {
            return refused("boundary-closed");
        }
        let head;
        try {
            head = readCanonicalHead();
        }
        catch (cause) {
            return Promise.resolve({ status: "refused", reason: "authority-unavailable", cause });
        }
        if (!head) {
            return refused("no-current-generation");
        }
        if (expected !== undefined && head.generationId !== expected) {
            return refused("generation-changed");
        }
        const entry = entries.get(head.generationId);
        if (!entry) {
            return refused("generation-unavailable");
        }
        return Promise.resolve().then(() => entry.start(args));
    }
    function sealBoundary() {
        sealed = true;
        for (const entry of entries.values()) {
            entry.control.seal();
        }
    }
    return Object.freeze({
        invoke: (...args) => selectAndInvoke(undefined, args),
        invokeExpected: (generationId, ...args) => selectAndInvoke(generationId, args),
        reserveGeneration, attachGeneration, seal: sealBoundary,
        generationControl: (generationId) => entries.get(generationId)?.control,
        generations: () => Object.freeze([...entries.values()].map((entry) => entry.control)),
        hasGenerationIdentity: (generationId) => usedIdentities.has(generationId),
        pending: () => sharedWork.size,
    });
}
