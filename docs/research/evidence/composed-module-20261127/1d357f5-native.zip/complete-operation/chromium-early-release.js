import { captureCleanupReport } from "./cleanup-report.js";
const notStarted = Object.freeze({ status: "not-started" });
/** The single exact instance owner; native Resources still owns every cleanup callback. */
class GenerationOwner {
    control;
    #generationId;
    #sharedWork;
    #maxActiveWork;
    #active = new Set();
    #drainWaiters = new Set();
    #forgetRegistration;
    #entry;
    #release;
    #sealed;
    #retained = true;
    #originalClose;
    #originalAttempt;
    #latestAttempt;
    #retryFlight;
    #retryCount = 0;
    constructor(options) {
        this.#generationId = options.generationId;
        this.#sharedWork = options.sharedWork;
        this.#maxActiveWork = options.maxActiveWork;
        this.#release = options.release;
        this.#sealed = options.sealed;
        this.#forgetRegistration = options.forgetRegistration;
        this.control = Object.freeze({
            generationId: this.#generationId,
            install: (entry) => this.#install(entry),
            seal: () => { this.#sealed = true; },
            pending: () => this.#active.size,
            drained: () => this.#drained(),
            close: () => this.#close(),
            retryCleanup: () => this.#retryCleanup(),
            originalCleanup: () => this.#originalAttempt?.native,
            snapshot: () => this.#snapshot(),
            forget: () => this.#forget(),
        });
    }
    start(args, parent) {
        if (parent ? !parent.acceptingChildren : this.#sealed) {
            return Promise.resolve({ status: "refused", reason: parent ? "continuation-closed" : "admission-closed" });
        }
        if (!this.#entry) {
            return Promise.resolve({ status: "refused", reason: "generation-unavailable" });
        }
        if (this.#sharedWork.size >= this.#maxActiveWork) {
            return Promise.resolve({ status: "refused", reason: "work-capacity" });
        }
        const completion = Promise.withResolvers();
        const record = { acceptingChildren: true, children: new Set(), parentChildren: parent?.children, completion, raw: undefined };
        this.#active.add(record);
        this.#sharedWork.add(record);
        parent?.children.add(completion.promise);
        const context = Object.freeze({
            generationId: this.#generationId,
            invoke: (...nested) => this.start(nested, record),
        });
        let call = this.#entry;
        try {
            const raw = Promise.resolve(call(context, ...args));
            record.raw = raw;
            void raw.then((value) => { this.#finish(record, { status: "returned", generationId: this.#generationId, value }); return; }, (cause) => { this.#finish(record, { status: "failed", generationId: this.#generationId, cause }); return; });
        }
        catch (cause) {
            this.#finish(record, { status: "failed", generationId: this.#generationId, cause });
        }
        finally {
            call = undefined;
        }
        return completion.promise;
    }
    #finish(record, outcome) {
        record.acceptingChildren = false;
        void Promise.all(record.children).then(() => {
            this.#active.delete(record);
            this.#sharedWork.delete(record);
            const completion = record.completion;
            // A closed escaped continuation keeps no raw promise, child result or resolver.
            record.raw = undefined;
            record.children.clear();
            if (completion) {
                record.parentChildren?.delete(completion.promise);
            }
            record.parentChildren = undefined;
            record.completion = undefined;
            completion?.resolve(outcome);
            if (this.#active.size === 0) {
                for (const resolve of this.#drainWaiters) {
                    resolve();
                }
                this.#drainWaiters.clear();
            }
            return;
        });
    }
    #install(entry) {
        if (!this.#retained) {
            return { status: "refused", reason: "forgotten" };
        }
        if (this.#sealed) {
            return { status: "refused", reason: "sealed" };
        }
        if (this.#entry) {
            return { status: "refused", reason: "already-installed" };
        }
        if (typeof entry !== "function") {
            return { status: "refused", reason: "invalid-entry" };
        }
        this.#entry = entry;
        return { status: "installed" };
    }
    #drained() {
        if (this.#active.size === 0) {
            return Promise.resolve();
        }
        return new Promise((resolve) => { this.#drainWaiters.add(resolve); });
    }
    #capture(attempt, value) {
        try {
            const report = captureCleanupReport(value);
            attempt.complete = report.complete;
            attempt.state = Object.freeze({ status: "settled", report });
            return report;
        }
        catch (cause) {
            // A malformed or abandon-only observation cannot authorize another cleanup.
            attempt.state = Object.freeze({ status: "failed", cause, retryable: false });
            throw cause;
        }
    }
    #beginCleanup(original) {
        const attempt = { state: Object.freeze({ status: "pending" }), complete: false, native: undefined, observation: undefined };
        this.#latestAttempt = attempt;
        if (original) {
            this.#originalAttempt = attempt;
        }
        let call = this.#release;
        let native;
        try {
            if (!call) {
                throw new Error("generation has no retained native cleanup owner");
            }
            native = call();
        }
        catch (cause) {
            native = Promise.reject(cause);
        }
        finally {
            call = undefined;
        }
        attempt.native = native;
        const observation = Promise.resolve(native).then((report) => this.#capture(attempt, report), (cause) => {
            attempt.state = Object.freeze({ status: "failed", cause, retryable: true });
            throw cause;
        });
        attempt.observation = observation;
        return observation;
    }
    #close() {
        if (this.#originalClose) {
            return this.#originalClose;
        }
        const completion = Promise.withResolvers();
        this.#originalClose = completion.promise;
        this.#sealed = true;
        void (async () => {
            await Promise.resolve(); // Deliberate defect: skip actual admitted-work drain.
            completion.resolve(await this.#beginCleanup(true));
        })().catch(completion.reject);
        return this.#originalClose;
    }
    #retryCleanup() {
        const latest = this.#latestAttempt;
        if (this.#retryFlight && latest?.state.status === "pending") {
            return this.#retryFlight;
        }
        if (!this.#originalClose || !latest || latest.state.status === "pending") {
            return Promise.reject(new Error("cleanup retry requires a settled original attempt"));
        }
        if (latest.complete && latest.observation) {
            return latest.observation;
        }
        if (latest.state.status === "failed" && !latest.state.retryable) {
            return Promise.reject(new Error("cleanup retry cannot proceed without the original native settlement"));
        }
        const completion = Promise.withResolvers();
        this.#retryFlight = completion.promise;
        this.#retryCount += 1;
        void this.#beginCleanup(false).then(completion.resolve, completion.reject);
        return this.#retryFlight;
    }
    #snapshot() {
        return Object.freeze({ generationId: this.#generationId, installed: this.#entry !== undefined,
            sealed: this.#sealed, retained: this.#retained, pendingWork: this.#active.size,
            cleanup: Object.freeze({ requested: this.#originalClose !== undefined, original: this.#originalAttempt?.state ?? notStarted,
                latest: this.#latestAttempt?.state ?? notStarted, retryCount: this.#retryCount }) });
    }
    #forget() {
        if (!this.#retained) {
            return { status: "forgotten" };
        }
        if (!this.#sealed) {
            return { status: "retained", reason: "admission-open" };
        }
        if (this.#active.size > 0) {
            return { status: "retained", reason: "work-pending" };
        }
        if (this.#latestAttempt?.complete !== true) {
            return { status: "retained", reason: "cleanup-incomplete" };
        }
        this.#forgetRegistration?.(this.control);
        this.#forgetRegistration = undefined;
        this.#entry = undefined;
        this.#release = undefined;
        this.#retained = false;
        return { status: "forgotten" };
    }
}
/** Internal construction; no provider callback or acquisition runs here. */
export function createGenerationRecord(options) {
    const owner = new GenerationOwner(options);
    return Object.freeze({ control: owner.control, start: (args) => owner.start(args) });
}
