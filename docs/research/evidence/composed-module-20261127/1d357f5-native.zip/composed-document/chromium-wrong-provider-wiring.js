import { assemblyFor } from "@get-modular/assembly";
import { documentComposition, plainFormatProvider } from "@fixture/portable-document-gm";
import { summaryGroup, summaryModule } from "../features/export-summary/composition/export-summary.group.js";
/** One actual selection owns the original Document/Format/Export/Summary factory set. */
export function closureComposition(provider) {
    const base = documentComposition(plainFormatProvider);
    return {
        profileId: "composed-document/" + base.profileId,
        modules: [...base.modules, summaryGroup],
        roots: { document: base.roots.document, publication: base.roots.export, summary: summaryModule },
        inputs: base.inputs,
    };
}
export function prepareClosure(provider, api = assemblyFor()) {
    return api.prepare(closureComposition(provider));
}
