"""Research witnesses using real SQLite and temporary files; not product code."""
import hashlib
import itertools
import json
import os
import platform
import sqlite3
import sys
import tempfile
from pathlib import Path


def connect(path):
    return sqlite3.connect(path, isolation_level=None)


def graph(root):
    """Two distinct writes can violate the same exclusive capability constraint."""
    result = {}
    for mode in ('target_only', 'read_set', 'read_set_disjoint'):
        path = root / (mode + '.db')
        with connect(path) as c:
            c.executescript('''CREATE TABLE members (name TEXT PRIMARY KEY, rev INT, claims INT);
              INSERT INTO members VALUES ('x',0,0), ('y',0,0), ('z',0,0);
              CREATE TABLE overall (rev INT); INSERT INTO overall VALUES (0);''')
        def snapshot(c):
            return {n: [r, k] for n,r,k in c.execute('SELECT * FROM members ORDER BY name')}
        with connect(path) as c, connect(path) as d:
            sx, sy = snapshot(c), snapshot(d)
            assert sx == sy == {'x':[0,0], 'y':[0,0], 'z':[0,0]}
            def prepare(s, key):
                proposed = {**s, key:[1,1]}
                assert sum(proposed[n][1] for n in ('x','y')) <= 1
                return proposed
            px, py = prepare(sx, 'x'), prepare(sy, 'y')
            if mode == 'read_set_disjoint':
                d.execute('BEGIN IMMEDIATE')
                d.execute("UPDATE members SET rev=1 WHERE name='z'")
                d.execute('UPDATE overall SET rev=rev+1')
                d.execute('COMMIT')
            def commit(conn, s, key):
                conn.execute('BEGIN IMMEDIATE')
                current = snapshot(conn)
                if mode != 'target_only' and any(current[n] != s[n] for n in ('x','y')):
                    conn.execute('ROLLBACK')
                    return 'stale-basis'
                changed = conn.execute('UPDATE members SET rev=rev+1,claims=1 WHERE name=? AND rev=?',
                                       (key,s[key][0])).rowcount
                if changed != 1:
                    conn.execute('ROLLBACK')
                    return 'conflict'
                conn.execute('UPDATE overall SET rev=rev+1')
                conn.execute('COMMIT')
                return 'committed'
            cx, cy = commit(c,sx,'x'), commit(d,sy,'y')
            final = snapshot(c)
            valid = sum(final[n][1] for n in ('x','y')) <= 1
            assert cx == 'committed'
            if mode == 'target_only':
                assert cy == 'committed' and not valid
            else:
                assert cy == 'stale-basis' and valid
            if mode == 'read_set_disjoint':
                assert final['z'] == [1,0]
            result[mode] = {'prepared_x':px,'prepared_y':py,'commit_x':cx,'commit_y':cy,
                            'final':final,'exclusive_constraint_holds':valid,
                            'overall_revision':c.execute('SELECT rev FROM overall').fetchone()[0]}
    return result


def state(root):
    """Reading a compatible format is not the same as preserving it on write."""
    result = {}
    for mode in ('blind_backfill', 'revision_guard'):
        with connect(root/(mode+'.db')) as c, connect(root/(mode+'.db')) as d:
            c.execute('CREATE TABLE document (rev INT, payload TEXT)')
            c.execute('INSERT INTO document VALUES(0,?)', (json.dumps({'text':'draft-A'}),))
            rev, body = c.execute('SELECT * FROM document').fetchone()
            staged = {**json.loads(body), 'schema':2, 'review':'pending'}
            d.execute('UPDATE document SET rev=rev+1,payload=?', (json.dumps({'text':'user-edit'}),))
            if mode == 'blind_backfill':
                rows = c.execute('UPDATE document SET rev=rev+1,payload=?', (json.dumps(staged),)).rowcount
            else:
                rows = c.execute('UPDATE document SET rev=rev+1,payload=? WHERE rev=?',
                                 (json.dumps(staged),rev)).rowcount
            current_rev, current_body = c.execute('SELECT * FROM document').fetchone()
            current = json.loads(current_body)
            assert rows == (1 if mode=='blind_backfill' else 0)
            assert current['text'] == ('draft-A' if mode=='blind_backfill' else 'user-edit')
            item = {'candidate_basis_revision':rev,'edited_revision':1,'changed_rows':rows,
                    'after_first_attempt':current,'revision':current_rev}
            if mode == 'revision_guard':
                new = {**current,'schema':2,'review':'pending'}
                assert c.execute('UPDATE document SET rev=rev+1,payload=? WHERE rev=?',
                                 (json.dumps(new),current_rev)).rowcount == 1
                item['replanned_document'] = json.loads(c.execute('SELECT payload FROM document').fetchone()[0])
                assert item['replanned_document']['text']=='user-edit'
            result[mode]=item
    # Old reader tolerates extra fields. Its replacement write still loses them.
    new_doc = json.loads(json.dumps({'text':'draft','review':'approved','review_rev':7}))
    old_projection = {'text':new_doc['text']}
    destructive = json.loads(json.dumps({**old_projection,'text':'edited'}))
    preserving = json.loads(json.dumps({**new_doc,'text':'edited'}))
    assert 'review' not in destructive and preserving['review']=='approved'
    result['tolerant_reader_destructive_writer']={'original':new_doc,'old_read_succeeded':True,
        'replacement_write':destructive,'field_preserving_control':preserving}
    return result


def retention(root):
    """A check of zero holders is stale unless attachment and retirement share authority."""
    result={}
    for mode in ('check_then_delete','sealed_delete'):
        folder=root/mode
        folder.mkdir()
        artifact=folder/'artifact-a.bin'
        artifact.write_bytes(b'old immutable content')
        path=folder/'owner.db'
        with connect(path) as c, connect(path) as d:
            c.executescript('''CREATE TABLE artifact (id TEXT PRIMARY KEY, state TEXT);
              INSERT INTO artifact VALUES ('artifact-a','available');
              CREATE TABLE hold (id TEXT PRIMARY KEY, artifact TEXT);''')
            count=lambda: c.execute("SELECT count(*) FROM hold WHERE artifact='artifact-a'").fetchone()[0]
            status=lambda: c.execute("SELECT state FROM artifact WHERE id='artifact-a'").fetchone()[0]
            def attach(conn):
                conn.execute('BEGIN IMMEDIATE')
                rows=conn.execute("INSERT INTO hold SELECT 'old-client',id FROM artifact WHERE id='artifact-a' AND state='available'").rowcount
                conn.execute('COMMIT')
                return rows
            assert count()==0
            if mode=='sealed_delete':
                c.execute('BEGIN IMMEDIATE')
                sealed=c.execute("UPDATE artifact SET state='deleting' WHERE id='artifact-a' AND state='available' AND NOT EXISTS(SELECT 1 FROM hold WHERE artifact='artifact-a')").rowcount
                assert sealed==1
                c.execute('COMMIT')
            attached=attach(d)
            artifact.unlink()
            if mode=='check_then_delete':
                assert attached==1 and count()==1 and not artifact.exists()
                result[mode]={'initial_holds':0,'late_attachment':attached,'final_holds':count(),
                              'physical_exists':artifact.exists(),'logical_state':status()}
            else:
                assert attached==0 and count()==0 and status()=='deleting'
                # The durable intent is still pending after physical unlink, before its receipt.
                observed={'state':status(),'exists':artifact.exists(),'holds':count()}
                assert observed=={'state':'deleting','exists':False,'holds':0}
                with connect(path) as recovery:
                    assert not artifact.exists()
                    updated=recovery.execute("UPDATE artifact SET state='deleted' WHERE id='artifact-a' AND state='deleting' AND NOT EXISTS(SELECT 1 FROM hold WHERE artifact='artifact-a')").rowcount
                    assert updated==1
                assert status()=='deleted' and attach(d)==0
                result[mode]={'initial_holds':0,'late_attachment':attached,'before_receipt':observed,
                              'reconciled_state':status(),'attachment_after_finalization':0}
    # Logical holds may all vanish while artifact/history obligations remain.
    hold_names=('active_call','pending_acquisition','borrowed_provider','cleanup_debt','uncertain_effect','old_client','rollback_hold')
    states=list(itertools.product((False,True),repeat=len(hold_names)))
    # The deliberately weak predicate considers only active calls.
    false_reclaims=[x for x in states if not x[0] and any(x[1:])]
    assert len(states)==128 and len(false_reclaims)==63
    result['finite_hold_model']={'hold_classes':hold_names,'states':len(states),
       'naive_zero_calls_allows':sum(not s[0] for s in states),
       'naive_false_reclaims':len(false_reclaims),'all_clear_states':sum(not any(s) for s in states),
       'note':'Boolean combinations, not observed frequencies; all-clear is necessary, not sufficient for external physical deletion.'}
    return result


def integrity(root):
    """Plain bytes, not code execution: path identity and transitive content differ."""
    digest=lambda x: hashlib.sha256(x).hexdigest()
    folder=root/'integrity';folder.mkdir()
    entry=folder/'entry.txt'; dependency=folder/'dependency.txt'
    entry.write_bytes(b'entry references dependency.txt')
    dependency.write_bytes(b'version-a')
    expected={p.name:digest(p.read_bytes()) for p in (entry,dependency)}
    verified_bytes=dependency.read_bytes()
    candidate=folder/'next.tmp';candidate.write_bytes(b'version-b')
    os.replace(candidate,dependency)
    actual={p.name:digest(p.read_bytes()) for p in (entry,dependency)}
    assert expected['entry.txt']==actual['entry.txt'] and expected['dependency.txt']!=actual['dependency.txt']
    assert digest(verified_bytes)==expected['dependency.txt']
    # A separate pathname validation/use gap, even for a root file.
    old_entry=entry.read_bytes();root_hash=digest(old_entry)
    candidate.write_bytes(b'other entry');os.replace(candidate,entry)
    assert digest(entry.read_bytes())!=root_hash and digest(old_entry)==root_hash
    return {'closure_expected':expected,'closure_observed':actual,'root_only_check_passes':True,
        'closure_check_rejects':True,'pathname_root_reopened_hash':digest(entry.read_bytes()),
        'previously_verified_root_hash':root_hash,'retained_small_byte_snapshot_matches':True,
        'note':'Only bytes are consumed. No JS loader, signatures, filesystem race-proofing, or sandbox is qualified.'}


def main():
    with tempfile.TemporaryDirectory(prefix='lmu-authority-') as d:
        root=Path(d)
        result={'scope':'Disposable SQLite and byte/JSON witnesses plus finite hold enumeration; no library or product execution',
                'python':sys.version,'sqlite':sqlite3.sqlite_version,
                'graph':graph(root),'state':state(root),'retention':retention(root),'integrity':integrity(root)}
        print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
