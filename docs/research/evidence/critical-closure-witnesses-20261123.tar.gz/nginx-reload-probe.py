"""Disposable loopback Nginx experiment. No application or updater code."""
import concurrent.futures
import http.client
import http.server
import json
import os
import re
import signal
import socket
import subprocess
import tempfile
import threading
import time
from pathlib import Path


def until(f, label, seconds=12):
    end = time.monotonic() + seconds
    last = None
    while time.monotonic() < end:
        try:
            last = f()
            if last:
                return last
        except (OSError, http.client.HTTPException):
            pass
        time.sleep(0.025)
    raise AssertionError(f'timeout: {label}, last={last!r}')


def request(port, path):
    con = http.client.HTTPConnection('127.0.0.1', port, timeout=30)
    try:
        con.request('GET', path, headers={'Connection': 'close'})
        reply = con.getresponse()
        return [reply.status, reply.getheader('X-Generation'), reply.read().decode()]
    finally:
        con.close()


def main():
    generation = {x: threading.Event() for x in ('a', 'b')}
    release = {x: threading.Event() for x in ('a', 'b')}

    class Upstream(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            label = self.path.rsplit('/', 1)[-1]
            generation[label].set()
            if not release[label].wait(25):
                self.send_error(504)
                return
            body = ('held-' + label).encode()
            self.send_response(200)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def log_message(self, *_):
            pass

    up = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Upstream)
    thread = threading.Thread(target=up.serve_forever, daemon=True)
    thread.start()
    reserved = socket.socket()
    reserved.bind(('127.0.0.1', 0))
    port = reserved.getsockname()[1]
    occupied = socket.socket()
    occupied.bind(('127.0.0.1', 0))
    occupied.listen()
    bad_port = occupied.getsockname()[1]
    results = {}
    master = None
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=2)
    with tempfile.TemporaryDirectory(prefix='lmu-nginx-') as directory:
        root = Path(directory)
        root.chmod(0o755)
        conf, log = root/'nginx.conf', root/'error.log'

        def logs():
            return log.read_text() if log.exists() else ''

        def config(g, bad=False):
            second = f'listen 127.0.0.1:{bad_port};' if bad else ''
            conf.write_text(f'''worker_processes 1;
error_log {log} notice;
pid {root}/nginx.pid;
worker_shutdown_timeout 20s;
daemon off;
events {{ worker_connections 128; }}
http {{
  access_log off;
  server {{
    listen 127.0.0.1:{port};
    {second}
    add_header X-Generation {g} always;
    location = /version {{ return 200 "{g}"; }}
    location /hold/ {{ proxy_pass http://127.0.0.1:{up.server_port}; proxy_read_timeout 25s; }}
  }}
}}
''')

        def worker_pids():
            return [int(x) for x in re.findall(r'start worker process (\d+)', logs())]

        def children():
            # ps reads the actual process parent relationships; the /proc task children
            # pseudo-file is not exposed in every Linux execution environment.
            listing = subprocess.run(['ps', '-o', 'pid=', '--ppid', str(master.pid)],
                                     capture_output=True, text=True, check=False)
            if listing.returncode not in (0, 1) or listing.stderr:
                raise RuntimeError(listing.stderr)
            return {int(x) for x in listing.stdout.split()}

        def activate(g):
            config(g)
            master.send_signal(signal.SIGHUP)
            return until(lambda: request(port, '/version') == [200, g, g], f'new traffic {g}')

        try:
            config('A')
            reserved.close()
            master = subprocess.Popen(['nginx','-p',str(root)+'/', '-c',str(conf)],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                      start_new_session=True, text=True)
            until(lambda: request(port, '/version') == [200, 'A', 'A'], 'initial A')
            a = until(lambda: worker_pids()[-1] if worker_pids() else None, 'worker A')
            fa = pool.submit(request, port, '/hold/a')
            assert generation['a'].wait(5), 'A upstream never entered'

            # A valid configuration cannot acquire an additional listening socket.
            config('X', bad=True)
            master.send_signal(signal.SIGHUP)
            until(lambda: 'still could not bind()' in logs(), 'failed resource acquisition')
            still_a = request(port, '/version')
            assert still_a == [200, 'A', 'A'] and not fa.done() and a in children()
            results['failed_candidate'] = {'old_new_request': still_a, 'old_held_pending': True,
                'new_worker_created': len(worker_pids()) != 1, 'bind_failure_observed': True}
            assert not results['failed_candidate']['new_worker_created']

            activate('B')
            b = until(lambda: worker_pids()[-1] if len(worker_pids()) >= 2 else None, 'worker B')
            assert a != b and a in children() and not fa.done()
            fb = pool.submit(request, port, '/hold/b')
            assert generation['b'].wait(5), 'B upstream never entered'
            activate('C')
            c = until(lambda: worker_pids()[-1] if len(worker_pids()) >= 3 else None, 'worker C')
            assert len({a,b,c}) == 3 and {a,b,c}.issubset(children())
            assert not fa.done() and not fb.done()
            results['overlapping_generations'] = {'fresh_request': request(port,'/version'),
                'old_a_pending': True, 'old_b_pending': True, 'live_worker_count_at_least': 3,
                'worker_pid_map': {'A': a, 'B': b, 'C': c}}

            release['b'].set()
            rb = fb.result(timeout=5)
            assert rb == [200,'B','held-b']
            until(lambda: b not in children(), 'B retired')
            assert a in children() and c in children() and not fa.done()
            results['out_of_order_retirement'] = {'B_response': rb, 'B_worker_reaped': True,
                'A_still_owned_and_pending': True, 'C_response': request(port,'/version')}
            release['a'].set()
            ra = fa.result(timeout=5)
            assert ra == [200,'A','held-a']
            until(lambda: a not in children(), 'A retired')
            assert children() == {c}
            results['final_retirement'] = {'A_response': ra, 'A_worker_reaped': True,
                'remaining_worker_is_C': True, 'fresh_request': request(port,'/version')}
            master.send_signal(signal.SIGQUIT)
            assert master.wait(timeout=8) == 0
            results['master_exit_code'] = master.returncode
            results['nginx_log'] = logs()
        finally:
            for event in release.values():
                event.set()
            if master is not None and master.poll() is None:
                try:
                    master.send_signal(signal.SIGQUIT)
                    master.wait(timeout=4)
                except subprocess.TimeoutExpired:
                    os.killpg(master.pid, signal.SIGKILL)
                    master.wait(timeout=4)
            if master is not None:
                master.stderr.close()
            pool.shutdown(wait=True, cancel_futures=True)
            up.shutdown()
            up.server_close()
            thread.join(timeout=3)
            occupied.close()
            reserved.close()
    print(json.dumps({'scope':'real Nginx worker/configuration reload on isolated loopback; not JS module replacement',
                      'nginx':subprocess.check_output(['nginx','-v'],stderr=subprocess.STDOUT,text=True).strip(),
                      'results':results}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
