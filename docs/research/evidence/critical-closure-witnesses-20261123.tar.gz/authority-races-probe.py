"""Additional bounded authority witnesses. Disposable DBs only; no provider calls."""
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path


def db(path):
    return sqlite3.connect(path, isolation_level=None)


def edge_race(root):
    output={}
    for mode in ('captured_only','revalidate_membership'):
        path=root/(mode+'.db')
        with db(path) as c, db(path) as d:
            c.executescript('''CREATE TABLE node (name TEXT PRIMARY KEY, rev INT, routable INT);
               INSERT INTO node VALUES ('provider',0,1), ('consumer',0,1);
               CREATE TABLE edge (consumer TEXT, provider TEXT, PRIMARY KEY(consumer,provider));''')
            def dependencies(conn):
                return [list(row) for row in conn.execute("SELECT consumer,provider FROM edge WHERE provider='provider' ORDER BY consumer")]
            observed=dependencies(c)
            assert observed==[]
            before=c.execute("SELECT rev FROM node WHERE name='provider'").fetchone()[0]
            # New reference appears after the preparation snapshot; no captured node changed.
            d.execute("INSERT INTO edge VALUES ('consumer','provider')")
            c.execute('BEGIN IMMEDIATE')
            current=dependencies(c)
            if mode=='revalidate_membership' and current!=observed:
                c.execute('ROLLBACK'); decision='stale-closure'
            else:
                assert c.execute("UPDATE node SET routable=0,rev=rev+1 WHERE name='provider' AND rev=?",(before,)).rowcount==1
                c.execute('COMMIT'); decision='retired'
            orphan=c.execute('SELECT count(*) FROM edge e JOIN node n ON n.name=e.provider WHERE n.routable=0').fetchone()[0]
            assert orphan==(1 if mode=='captured_only' else 0)
            output[mode]={'captured_edges':observed,'actual_edges':current,'decision':decision,'dangling_active_edges':orphan}
    return output


def receiver_apply(path,key,intent,idempotent):
    with db(path) as c:
        c.execute('BEGIN IMMEDIATE')
        found=c.execute('SELECT intent,effect_id FROM receipt WHERE request=?',(key,)).fetchone()
        if found is not None:
            c.execute('ROLLBACK')
            return ['replay',found[1]] if found[0]==intent else ['intent-mismatch']
        effect=c.execute('INSERT INTO effect(intent) VALUES (?)',(intent,)).lastrowid
        if idempotent:
            c.execute('INSERT INTO receipt VALUES(?,?,?)',(key,intent,effect))
        c.execute('COMMIT')
        return ['applied',effect]


def independent_effect(root):
    output={}
    for mode in ('no_receiver_receipt','receiver_receipt','expired_receipt'):
        authority=root/(mode+'-controller.db'); target=root/(mode+'-receiver.db')
        with db(authority) as c:
            c.executescript("CREATE TABLE intent (request TEXT PRIMARY KEY,state TEXT); INSERT INTO intent VALUES ('r1','dispatch-claimed');")
        with db(target) as c:
            c.executescript('''CREATE TABLE effect (id INTEGER PRIMARY KEY,intent TEXT);
            CREATE TABLE receipt (request TEXT PRIMARY KEY,intent TEXT,effect_id INT);''')
        process=subprocess.run([sys.executable,__file__,'child',str(target),'0' if mode=='no_receiver_receipt' else '1'],capture_output=True,text=True)
        assert (process.returncode,process.stdout,process.stderr)==(73,'','')
        with db(authority) as c, db(target) as d:
            pending=c.execute('SELECT state FROM intent').fetchone()[0]
            first=d.execute('SELECT count(*) FROM effect').fetchone()[0]
            assert first==1 and pending=='dispatch-claimed'
            if mode=='expired_receipt':
                d.execute('DELETE FROM receipt') # controlled expiration scenario, not real TTL or provider behavior
            replay=receiver_apply(target,'r1','send-message',mode!='no_receiver_receipt')
            effects=d.execute('SELECT count(*) FROM effect').fetchone()[0]
            assert effects==(1 if mode=='receiver_receipt' else 2)
            item={'child_exit':73,'controller_state_after_lost_reply':pending,'receiver_effects_before_retry':first,
                  'retry_outcome':replay,'receiver_effects_after_retry':effects}
            if mode=='receiver_receipt':
                item['different_intent']=receiver_apply(target,'r1','different-message',True)
                assert item['different_intent']==['intent-mismatch'] and d.execute('SELECT count(*) FROM effect').fetchone()[0]==1
            output[mode]=item
    return output


def projection(root):
    output={}
    for mode in ('blind_projection','monotonic_fence'):
        with db(root/(mode+'.db')) as c:
            c.executescript("CREATE TABLE decision (revision INT, allowed INT); INSERT INTO decision VALUES (1,1);")
            c.execute('UPDATE decision SET revision=2,allowed=0')
            guard=' WHERE revision<1' if mode=='monotonic_fence' else ''
            rows=c.execute('UPDATE decision SET revision=1,allowed=1'+guard).rowcount
            observed=list(c.execute('SELECT revision,allowed FROM decision').fetchone())
            assert observed==([1,1] if mode=='blind_projection' else [2,0])
            output[mode]={'revoked_revision':2,'late_grant_revision':1,'changed_rows':rows,'local_projection':observed,'new_admission_allowed':bool(observed[1])}
    return output


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='child':
        result=receiver_apply(Path(sys.argv[2]),'r1','send-message',sys.argv[3]=='1')
        assert result==['applied',1]
        os._exit(73)
    with tempfile.TemporaryDirectory(prefix='lmu-races-') as d:
        root=Path(d)
        print(json.dumps({'scope':'deterministic two-owner SQLite/file witnesses; no PostgreSQL, actual network or provider',
            'python':sys.version,'sqlite':sqlite3.sqlite_version,'new_dependency':edge_race(root),
            'independent_receiver':independent_effect(root),'projection_reordering':projection(root)},indent=2,sort_keys=True))
